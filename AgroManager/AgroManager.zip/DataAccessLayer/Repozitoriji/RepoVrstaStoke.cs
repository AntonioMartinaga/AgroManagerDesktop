﻿using EntitiesLayer.Entiteti;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repozitoriji
{
    public class RepoVrstaStoke : Repo<Vrsta_stoke>
    {
        public RepoVrstaStoke() : base(new AgroManagerModel())
        {
        }

        public override int Azuriraj(Vrsta_stoke entitet, bool spremiPromjene = true)
        {
            throw new NotImplementedException();
        }

    }
}
