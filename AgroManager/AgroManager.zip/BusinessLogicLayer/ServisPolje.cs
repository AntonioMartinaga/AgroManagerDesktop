﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Repozitoriji;
using EntitiesLayer.Entiteti;

namespace BusinessLogicLayer
{
    public class ServisPolje
    {
        private RepoPolje RepoPolje;

        public ServisPolje() 
        {
            RepoPolje = new RepoPolje();
        }

        public List<Polje> DohvatiPolja()
        {
            return RepoPolje.DohvatiPolja().ToList();
        }

        public Polje DohvatiPolje(int idPolje)
        {
            return RepoPolje.DohvatiPoljePoId(idPolje);
        }

        public List<Polje> DohvatiPoljaPoduzeca(int idPoduzeca)
        {
            return RepoPolje.DohvatiPoljaPoduzeca(idPoduzeca).ToList();
        }
    }
}
