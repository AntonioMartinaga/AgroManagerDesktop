﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer.Enumeracije
{
    internal enum EnumVrstaVozila
    {
        Traktor,
        Kamion,
        Automobil,
        Bager,
        Kombajn,
        Kombi,
        Utovarivač,
    }
}
