﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer.Enumeracije
{
    public enum EnumPolozeneKategorije
    {
        AM,
        A1,
        A2,
        A,
        B,
        BE,
        C1,
        C1E,
        C,
        CE,
        D1,
        D1E,
        D,
        DE,
        F,
        G,
        H
    }
}
