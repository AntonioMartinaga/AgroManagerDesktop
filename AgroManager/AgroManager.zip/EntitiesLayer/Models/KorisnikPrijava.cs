﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntitiesLayer.Models
{
    public class KorisnikPrijava
    {
        public string Korisnicko_ime { get; set; }
        public string Lozinka { get; set; }
    }
}