﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntitiesLayer.Models
{
    public class UnutarnjaGreska
    {
        public string Message { get; set; }
        public string ExceptionMessage { get; set; }
    }
}