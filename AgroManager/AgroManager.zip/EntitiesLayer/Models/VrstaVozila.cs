﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer.Models
{
    public class VrstaVozila
    {
        public static List<string> ListaVrstaVozila = new List<string> {
            "Traktor",
            "Kamion",
            "Automobil",
            "Bager",
            "Kombajn",
            "Kombi",
            "Utovarivač",
        };
    }
}
